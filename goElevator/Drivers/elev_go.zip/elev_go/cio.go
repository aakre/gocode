/*
Wrapper for io.c
Works with gccgo, not gc

Written by Tore Egil Halse
*/
package cio

//Indentifiers for c functions
func c_init         ()               int __asm__ ("io_init");
func c_set_bit      (int)                __asm__ ("io_set_bit");
func c_clear_bit    (int)                __asm__ ("io_clear_bit");
func c_write_analog (int, value int)     __asm__ ("io_write_analog");
func c_read_bit     (int)            int __asm__ ("io_read_bit");
func c_read_analog  (int)            int __asm__ ("io_read_analog");


//Indentifiers used by the driver

func Init () bool {
	return c_init() == -1
}

func Set_bit (channel int) {
	c_set_bit(channel)
}

func Clear_bit (channel int) {
	c_clear_bit(channel)
}

func Write_analog (channel int, value int) {
	c_write_analog(channel, value)
}

func Read_bit (channel int) bool {
	return c_read_bit(channel) > 0
}

func Read_analog (channel int) int {
	return c_read_analog(channel)
}
