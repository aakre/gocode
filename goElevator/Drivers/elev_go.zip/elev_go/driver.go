package driver
import "./cio"
import "./channels"
import "fmt"
import "time"

type Direction int
const (
	NONE Direction = iota
	UP
	DOWN
)

type button struct {
	floor int
	dir Direction
}

const MAX_SPEED = 4024
const MIN_SPEED = 2048

func Init() {
	val := cio.Init()
	if !val {
		fmt.Printf("Driver initiated\n")
	} else {
		fmt.Printf("Driver not initiated\n")
	}

	ClearDoor()
	ClearStopButton()
	ClearLight(1, UP)
	ClearLight(2, UP)
	ClearLight(3, UP)
	ClearLight(2, DOWN)
	ClearLight(3, DOWN)
	ClearLight(4, DOWN)
	ClearLight(1, NONE)
	ClearLight(2, NONE)
	ClearLight(3, NONE)
	ClearLight(4, NONE)

	buttonChan = make(chan button)
	floorChan = make(chan int)
	motorChan = make(chan Direction)
	stopButtonChan = make(chan bool)
	obsChan = make(chan bool)

	go listen()
	go motorHandler()
}

var buttonChan chan button
var floorChan chan int
var motorChan chan Direction
var stopButtonChan chan bool
var obsChan chan bool

func motorHandler() {
	currentDir := NONE
	cio.Write_analog(channels.MOTOR, MIN_SPEED)
	for {
		newDir := <- motorChan
		if (newDir == NONE) && (currentDir == UP) {
			cio.Set_bit(channels.MOTORDIR)
			cio.Write_analog(channels.MOTOR, MIN_SPEED)
		} else if (newDir == NONE) && (currentDir == DOWN) {
			cio.Clear_bit(channels.MOTORDIR)
			cio.Write_analog(channels.MOTOR, MIN_SPEED)
		} else if (newDir == UP) {
			cio.Clear_bit(channels.MOTORDIR)
			cio.Write_analog(channels.MOTOR, MAX_SPEED)
		} else if (newDir == DOWN) {
			cio.Set_bit(channels.MOTORDIR)
			cio.Write_analog(channels.MOTOR, MAX_SPEED)
		} else {
			cio.Write_analog(channels.MOTOR, MIN_SPEED)
		}
		currentDir = newDir
	}
}

func listen() {
	var floorMap = map[int] int {
		channels.SENSOR1 : 1,
		channels.SENSOR2 : 2,
		channels.SENSOR3 : 3,
		channels.SENSOR4 : 4,
	}

	var buttonMap = map[int] button {
		channels.FLOOR_COMMAND1 : { 1, NONE },
		channels.FLOOR_COMMAND2 : { 2, NONE },
		channels.FLOOR_COMMAND3 : { 3, NONE },
		channels.FLOOR_COMMAND4 : { 4, NONE },
		channels.FLOOR_UP1      : { 1,   UP },
		channels.FLOOR_UP2      : { 2,   UP },
		channels.FLOOR_UP3      : { 3,   UP },
		channels.FLOOR_DOWN2    : { 2, DOWN },
		channels.FLOOR_DOWN3    : { 3, DOWN },
		channels.FLOOR_DOWN4    : { 4, DOWN },
	}

	buttonList := make(map[int]bool)
	for key, _ := range buttonMap {
		buttonList[key] = cio.Read_bit(key)
	}

	floorList := make(map[int]bool)
	for key, _ := range floorMap {
		floorList[key] = cio.Read_bit(key)
	}

	oldStop := false
	oldObs := false

	for {
		time.Sleep(1E7)
		for key, floor := range floorMap {
			newValue := cio.Read_bit(key)
			if newValue != floorList[key] {
				newFloor := floor
				go func() {
					floorChan <- newFloor
				}()
			}
			floorList[key] = newValue
		}

		for key, btn := range buttonMap {
			newValue := cio.Read_bit(key)
			if newValue && !buttonList[key] {
				newButton := btn
				go func() {
					buttonChan <- newButton
				}()
			}
			buttonList[key] = newValue
		}

		newStop := cio.Read_bit(channels.STOP)
		if newStop && !oldStop {
			go func() {
				stopButtonChan <- true
			}()
		}
		oldStop = newStop

		newObs := cio.Read_bit(channels.OBSTRUCTION)
		if newObs != oldObs {
			go func() {
				obsChan <- newObs
			}()
		}
		oldObs = newObs
	}

}


func SetLight (floor int, dir Direction) {
	switch {
	case	floor == 1 && dir == NONE:
			cio.Set_bit(channels.LIGHT_COMMAND1)
	case	floor == 2 && dir == NONE:
			cio.Set_bit(channels.LIGHT_COMMAND2)
	case	floor == 3 && dir == NONE:
			cio.Set_bit(channels.LIGHT_COMMAND3)
	case	floor == 4 && dir == NONE:
			cio.Set_bit(channels.LIGHT_COMMAND4)
	case	floor == 1 && dir == UP:
			cio.Set_bit(channels.LIGHT_UP1)
	case	floor == 2 && dir == UP:
			cio.Set_bit(channels.LIGHT_UP2)
	case	floor == 3 && dir == UP:
			cio.Set_bit(channels.LIGHT_UP3)
	case	floor == 2 && dir == DOWN:
			cio.Set_bit(channels.LIGHT_DOWN2)
	case	floor == 3 && dir == DOWN:
			cio.Set_bit(channels.LIGHT_DOWN3)
	case	floor == 4 && dir == DOWN:
			cio.Set_bit(channels.LIGHT_DOWN4)
	}
}

func ClearLight (floor int, dir Direction) {
	switch {
	case	floor == 1 && dir == NONE:
			cio.Clear_bit(channels.LIGHT_COMMAND1)
	case	floor == 2 && dir == NONE:
			cio.Clear_bit(channels.LIGHT_COMMAND2)
	case	floor == 3 && dir == NONE:
			cio.Clear_bit(channels.LIGHT_COMMAND3)
	case	floor == 4 && dir == NONE:
			cio.Clear_bit(channels.LIGHT_COMMAND4)
	case	floor == 1 && dir == UP:
			cio.Clear_bit(channels.LIGHT_UP1)
	case	floor == 2 && dir == UP:
			cio.Clear_bit(channels.LIGHT_UP2)
	case	floor == 3 && dir == UP:
			cio.Clear_bit(channels.LIGHT_UP3)
	case	floor == 2 && dir == DOWN:
			cio.Clear_bit(channels.LIGHT_DOWN2)
	case	floor == 3 && dir == DOWN:
			cio.Clear_bit(channels.LIGHT_DOWN3)
	case	floor == 4 && dir == DOWN:
			cio.Clear_bit(channels.LIGHT_DOWN4)
	}
}

func MotorUp () {
	motorChan <- UP
}

func MotorDown () {
	motorChan <- DOWN
}

func MotorStop () {
	motorChan <- NONE
}

func GetButton () (int, Direction) {
	btn :=  <- buttonChan
	return btn.floor, btn.dir
}

func GetFloor () (int) {
	floor :=  <- floorChan
	return floor
}

func SetFloor (floor int) {
	switch floor {
	case 1:
		cio.Clear_bit (channels.FLOOR_IND1)
		cio.Clear_bit (channels.FLOOR_IND2)
	case 2:
		cio.Clear_bit (channels.FLOOR_IND1)
		cio.Set_bit   (channels.FLOOR_IND2)
	case 3:
		cio.Set_bit   (channels.FLOOR_IND1)
		cio.Clear_bit (channels.FLOOR_IND2)
	case 4:
		cio.Set_bit   (channels.FLOOR_IND1)
		cio.Set_bit   (channels.FLOOR_IND2)
	}
}

func GetStopButton () {
	<- stopButtonChan
}

func SetStopButton() {
	cio.Set_bit(channels.LIGHT_STOP)
}

func ClearStopButton() {
	cio.Clear_bit(channels.LIGHT_STOP)
}

func GetObs() bool {
	return <- obsChan
}

func SetDoor() {
	cio.Set_bit(channels.DOOR_OPEN)
}

func ClearDoor() {
	cio.Clear_bit(channels.DOOR_OPEN)
}
